# abm_reasoner.py
# ------------------------------------------------------------
# ABM DocFlow - Reasoner (explica / resume un *_ANALISIS_ABM.json)
# - Lee el JSON de evidencia (salida del extractor "viejo")
# - Llama a Ollama para generar un resumen y recomendaciones
# - Guarda un *_REASONER.json y *_REASONER.txt al lado del input
#
# Requisitos:
#   pip install requests
#
# Ejemplo:
#   python abm_reasoner.py --input H:\abm\salidas\ABC_ANALISIS_ABM.json --model deepseek-r1:7b
#   python abm_reasoner.py --input ... --model llama3.1:8b --base-url http://localhost:11434
# ------------------------------------------------------------

from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, List

import requests


def _now_iso() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def _safe_json_loads(s: str) -> Optional[Any]:
    try:
        return json.loads(s)
    except Exception:
        return None


def _extract_json_object(s: str) -> Optional[Dict[str, Any]]:
    """
    Intenta recuperar el primer objeto JSON válido dentro de una respuesta de LLM
    aunque venga con texto extra, fences, etc.
    """
    s = (s or "").strip()
    if not s:
        return None

    obj = _safe_json_loads(s)
    if isinstance(obj, dict):
        return obj

    # Quitar fences ```json ... ```
    s2 = re.sub(r"^```(?:json)?\s*", "", s, flags=re.IGNORECASE).strip()
    s2 = re.sub(r"\s*```$", "", s2).strip()
    obj = _safe_json_loads(s2)
    if isinstance(obj, dict):
        return obj

    start = s2.find("{")
    if start == -1:
        return None

    depth = 0
    for i in range(start, len(s2)):
        ch = s2[i]
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                candidate = s2[start:i + 1]
                obj = _safe_json_loads(candidate)
                if isinstance(obj, dict):
                    return obj
                return None
    return None


@dataclass
class OllamaCfg:
    base_url: str = "http://localhost:11434"
    model: str = "deepseek-r1:7b"
    timeout_s: int = 90


class OllamaClient:
    def __init__(self, cfg: OllamaCfg):
        self.cfg = cfg
        self.session = requests.Session()

    def generate(self, prompt: str, temperature: float = 0.2) -> str:
        url = self.cfg.base_url.rstrip("/") + "/api/generate"
        payload = {
            "model": self.cfg.model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": temperature},
        }
        r = self.session.post(url, json=payload, timeout=self.cfg.timeout_s)
        r.raise_for_status()
        data = r.json()
        return (data.get("response") or "").strip()


SYSTEM = """Sos un asistente institucional. Te voy a pasar un JSON de análisis de un documento (ABM).
Tu tarea es producir un resumen y recomendaciones operativas. Tu respuesta debe ser SOLO un JSON válido (sin markdown).
Reglas:
- No inventes datos que no estén presentes.
- Si hay faltantes, marcarlos como faltantes_criticos.
- Si hay inconsistencias u OCR dudoso, listarlo en riesgos_detectados.
- Sé práctico y corto.
"""

USER_TMPL = """JSON de entrada:
{JSON}

Devolvé un JSON con esta estructura exacta:

{{
  "resumen": "",
  "faltantes_criticos": [],
  "riesgos_detectados": [],
  "recomendaciones": []
}}

IMPORTANTE:
- No agregues keys nuevas.
- SOLO JSON válido.
"""


def build_prompt(payload: Dict[str, Any]) -> str:
    pretty = json.dumps(payload, ensure_ascii=False, indent=2)
    return f"SYSTEM:\n{SYSTEM}\n\nUSER:\n" + USER_TMPL.format(JSON=pretty)


def run_reasoner(input_path: Path, client: OllamaClient) -> Dict[str, Any]:
    raw = json.loads(input_path.read_text(encoding="utf-8", errors="ignore"))
    prompt = build_prompt(raw)

    text = client.generate(prompt)
    parsed = _extract_json_object(text)

    out: Dict[str, Any] = {
        "ok": parsed is not None,
        "timestamp_utc": _now_iso(),
        "input_file": str(input_path),
        "ollama": {
            "base_url": client.cfg.base_url,
            "model": client.cfg.model,
        },
        "raw_text": text,
        "data": parsed,
    }
    return out


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="ABM - Reasoner (resume y recomienda) sobre *_ANALISIS_ABM.json")
    p.add_argument("--input", required=True, help="Ruta al *_ANALISIS_ABM.json")
    p.add_argument("--model", default="deepseek-r1:7b", help="Modelo Ollama (ej: deepseek-r1:7b)")
    p.add_argument("--base-url", default="http://localhost:11434", help="Base URL Ollama")
    p.add_argument("--timeout", type=int, default=90, help="Timeout segundos")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    inp = Path(args.input).expanduser().resolve()
    if not inp.exists():
        raise FileNotFoundError(f"No existe: {inp}")

    cfg = OllamaCfg(base_url=args.base_url, model=args.model, timeout_s=int(args.timeout))
    client = OllamaClient(cfg)

    result = run_reasoner(inp, client)

    out_json = inp.with_name(inp.stem.replace("_ANALISIS_ABM", "") + "_REASONER.json")
    out_txt = inp.with_name(inp.stem.replace("_ANALISIS_ABM", "") + "_REASONER.txt")

    out_json.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    # un txt humano para leer rápido
    if result.get("data") and isinstance(result["data"], dict):
        d = result["data"]
        lines: List[str] = []
        lines.append(d.get("resumen", "").strip() or "(sin resumen)")
        if d.get("faltantes_criticos"):
            lines.append("\nFaltantes críticos:")
            for it in d["faltantes_criticos"]:
                lines.append(f"- {it}")
        if d.get("riesgos_detectados"):
            lines.append("\nRiesgos detectados:")
            for it in d["riesgos_detectados"]:
                lines.append(f"- {it}")
        if d.get("recomendaciones"):
            lines.append("\nRecomendaciones:")
            for it in d["recomendaciones"]:
                lines.append(f"- {it}")
        out_txt.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")
    else:
        out_txt.write_text(result.get("raw_text","") + "\n", encoding="utf-8")

    print(f"[OK] {out_json}")
    print(f"[OK] {out_txt}")
    return 0 if result.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(main())
