import json
import os
import re
import tkinter as tk
from tkinter import filedialog, messagebox
from pathlib import Path
from datetime import date, datetime

ROOT = Path(__file__).resolve().parent
IN_DEFAULT = ROOT / "json_llm" / "03_aportes" / "socios"
OUT_SOCIOS = ROOT / "json_llm" / "04_estado" / "socios"
OUT_RESUMEN = ROOT / "json_llm" / "04_estado" / "resumen.json"

# ==========================
# Requisitos (default)
# - key debe coincidir con aporte_key (ej: ejercicio.seguro_mala_praxis)
# - bloquea=True: si falta o está vencido -> BLOQUEA
# ==========================
DEFAULT_REQUISITOS = [
    # 1) OBLIGATORIOS BLOQUEANTES
    {"key": "identidad.dni", "label": "DNI", "tipo": "obligatorio", "vence": False, "prioridad": "media", "bloquea": True},
    {"key": "fiscal.afip_arca", "label": "Constancia AFIP/ARCA", "tipo": "obligatorio", "vence": True, "prioridad": "alta", "bloquea": True},
    {"key": "fiscal.ingresos_brutos", "label": "Ingresos Brutos (ATM/ARBA)", "tipo": "obligatorio", "vence": True, "prioridad": "alta", "bloquea": True},
    {"key": "profesion.titulo_habilitante", "label": "Título habilitante", "tipo": "obligatorio", "vence": False, "prioridad": "alta", "bloquea": True},
    {"key": "profesion.matricula", "label": "Matrícula profesional", "tipo": "obligatorio", "vence": True, "prioridad": "alta", "bloquea": True},
    {"key": "profesion.sss", "label": "Inscripción SSS (prestador)", "tipo": "obligatorio", "vence": True, "prioridad": "alta", "bloquea": True},
    {"key": "ejercicio.seguro_mala_praxis", "label": "Seguro de mala praxis", "tipo": "obligatorio", "vence": True, "prioridad": "alta", "bloquea": True},
    {"key": "ejercicio.habilitacion_laboratorio", "label": "Habilitación de laboratorio (si corresponde)", "tipo": "obligatorio", "vence": True, "prioridad": "alta", "bloquea": False},
    {"key": "ejercicio.director_tecnico", "label": "Designación Director Técnico (si corresponde)", "tipo": "obligatorio", "vence": True, "prioridad": "media", "bloquea": False},

    # 2) CONDICIONALES (no bloquean por defecto)
    {"key": "adhesiones.abm", "label": "Adhesión ABM", "tipo": "condicional", "vence": True, "prioridad": "media", "bloquea": False},
    {"key": "adhesiones.osep", "label": "Adhesión OSEP", "tipo": "condicional", "vence": True, "prioridad": "media", "bloquea": False},
    {"key": "adhesiones.pami", "label": "Adhesión PAMI", "tipo": "condicional", "vence": True, "prioridad": "media", "bloquea": False},
    {"key": "adhesiones.convenios_pago", "label": "Aceptación de pago / convenios", "tipo": "condicional", "vence": True, "prioridad": "media", "bloquea": False},

    # 3) DATOS ÚTILES (no bloquean)
    {"key": "admin.cuenta_bancaria", "label": "Cuenta bancaria (CBU/Alias)", "tipo": "dato", "vence": False, "prioridad": "baja", "bloquea": False},
]

# Si existe un archivo abm_requisitos.json en la raíz, lo usa (para que lo adaptes sin tocar código)
REQ_FILE = ROOT / "abm_requisitos.json"


# ----------------- utils -----------------
def safe_uid(s: str) -> str:
    s = str(s).strip()
    s = re.sub(r"\W+", "_", s).strip("_")
    return s[:80] if s else "SIN_ID"

def parse_iso_date(s: str):
    if not s:
        return None
    try:
        return date.fromisoformat(s[:10])
    except Exception:
        return None

def today_local() -> date:
    return date.today()

def now_ts() -> str:
    return datetime.now().isoformat(timespec="seconds")


def load_requisitos():
    if REQ_FILE.exists():
        try:
            data = json.loads(REQ_FILE.read_text(encoding="utf-8"))
            if isinstance(data, list) and data:
                return data
        except Exception:
            pass
    return DEFAULT_REQUISITOS


def evaluar_item(req, aporte_obj, hoy: date, dias_prox: int):
    """
    Devuelve dict con estado del requisito.
    Estados: OK | FALTANTE | VENCIDO | PROXIMO | REVISAR
    """
    key = req["key"]
    vence = bool(req.get("vence"))
    bloquea = bool(req.get("bloquea"))
    prioridad = req.get("prioridad", "media")
    label = req.get("label", key)
    tipo = req.get("tipo", "obligatorio")

    if aporte_obj is None:
        return {
            "key": key, "label": label, "tipo": tipo,
            "estado": "FALTANTE",
            "vence": vence, "bloquea": bloquea, "prioridad": prioridad,
            "vigencia": None,
            "detalle": "No hay aporte registrado para este requisito."
        }

    # Si no vence, con que esté presente ya está OK
    vig = (aporte_obj.get("vigencia") or {})
    desde = parse_iso_date(vig.get("desde"))
    hasta = parse_iso_date(vig.get("hasta"))
    conf = vig.get("confianza")
    fuente = vig.get("fuente")

    if not vence:
        return {
            "key": key, "label": label, "tipo": tipo,
            "estado": "OK",
            "vence": False, "bloquea": bloquea, "prioridad": prioridad,
            "vigencia": {"desde": vig.get("desde"), "hasta": vig.get("hasta"), "confianza": conf, "fuente": fuente},
            "detalle": "Presente (no vence)."
        }

    # Vence pero no hay fecha -> REVISAR
    if hasta is None:
        return {
            "key": key, "label": label, "tipo": tipo,
            "estado": "REVISAR",
            "vence": True, "bloquea": bloquea, "prioridad": prioridad,
            "vigencia": {"desde": vig.get("desde"), "hasta": vig.get("hasta"), "confianza": conf, "fuente": fuente},
            "detalle": "Presente, pero no se detectó fecha de vencimiento (revisar)."
        }

    # Evaluar vencido / próximo
    days_left = (hasta - hoy).days

    if days_left < 0:
        return {
            "key": key, "label": label, "tipo": tipo,
            "estado": "VENCIDO",
            "vence": True, "bloquea": bloquea, "prioridad": prioridad,
            "vigencia": {"desde": vig.get("desde"), "hasta": vig.get("hasta"), "confianza": conf, "fuente": fuente},
            "detalle": f"Vencido hace {-days_left} día(s)."
        }

    if days_left <= dias_prox:
        return {
            "key": key, "label": label, "tipo": tipo,
            "estado": "PROXIMO",
            "vence": True, "bloquea": bloquea, "prioridad": prioridad,
            "vigencia": {"desde": vig.get("desde"), "hasta": vig.get("hasta"), "confianza": conf, "fuente": fuente},
            "detalle": f"Vence en {days_left} día(s)."
        }

    return {
        "key": key, "label": label, "tipo": tipo,
        "estado": "OK",
        "vence": True, "bloquea": bloquea, "prioridad": prioridad,
        "vigencia": {"desde": vig.get("desde"), "hasta": vig.get("hasta"), "confianza": conf, "fuente": fuente},
        "detalle": f"Vigente. Vence en {days_left} día(s)."
    }


def determinar_estado_global(items_eval):
    """
    Reglas:
    - Si hay VENCIDO bloqueante o FALTANTE bloqueante -> BLOQUEA
    - Si hay PROXIMO (alta) o REVISAR (alta) -> REVISAR
    - Si hay cualquier FALTANTE/REVISAR/PROXIMO no bloqueante -> REVISAR
    - Si todo OK -> OK
    """
    def is_block(e):
        return e.get("bloquea") and e.get("estado") in ("FALTANTE", "VENCIDO")

    if any(is_block(e) for e in items_eval):
        return "BLOQUEA"

    if any(e.get("estado") in ("PROXIMO", "REVISAR", "FALTANTE") for e in items_eval):
        return "REVISAR"

    return "OK"


def build_notificaciones(items_eval):
    notas = []
    for e in items_eval:
        st = e["estado"]
        if st == "OK":
            continue
        sev = "baja"
        if e.get("prioridad") == "alta":
            sev = "alta"
        elif e.get("prioridad") == "media":
            sev = "media"

        notas.append({
            "severidad": sev,
            "estado": st,
            "key": e["key"],
            "label": e["label"],
            "detalle": e.get("detalle")
        })
    # ordenar: alta primero, luego estado, etc.
    order = {"alta": 0, "media": 1, "baja": 2}
    notas.sort(key=lambda x: (order.get(x["severidad"], 9), x["estado"], x["label"]))
    return notas


def process_socio_file(p: Path, requisitos, dias_prox: int):
    socio = json.loads(p.read_text(encoding="utf-8", errors="ignore"))

    socio_uid_safe = socio.get("socio_uid_safe") or safe_uid(p.stem.replace("SOCIO_", ""))
    hoy = today_local()

    aportes_resumen = socio.get("aportes_resumen") or {}
    # aportes_resumen puede ser dict {key: aporte_obj}
    # o a veces venir como lista; lo normalizamos
    if isinstance(aportes_resumen, list):
        tmp = {}
        for it in aportes_resumen:
            k = it.get("aporte_key")
            if k:
                tmp[k] = it
        aportes_resumen = tmp

    items_eval = []
    for req in requisitos:
        key = req["key"]
        aporte_obj = aportes_resumen.get(key)
        items_eval.append(evaluar_item(req, aporte_obj, hoy, dias_prox))

    estado_global = determinar_estado_global(items_eval)
    notificaciones = build_notificaciones(items_eval)

    out = {
        "schema": "abm_socio_estado_v1",
        "fecha_proceso": now_ts(),
        "hoy": hoy.isoformat(),
        "socio_uid_safe": socio_uid_safe,
        "campos_consolidados": socio.get("campos_consolidados") or {},
        "estado_global": estado_global,
        "items": items_eval,
        "notificaciones": notificaciones,
        "input": {
            "socio_aportes_json": str(p)
        }
    }
    return socio_uid_safe, out


def run_gui():
    try:
        dias_prox = int(dias_var.get().strip() or "30")

        files = filedialog.askopenfilenames(
            title="Seleccionar SOCIO_*.json (desde json_llm/03_aportes/socios)",
            initialdir=str(IN_DEFAULT) if IN_DEFAULT.exists() else str(ROOT),
            filetypes=[("SOCIO aportes", "SOCIO_*.json"), ("JSON", "*.json")]
        )
        if not files:
            return

        requisitos = load_requisitos()

        OUT_SOCIOS.mkdir(parents=True, exist_ok=True)
        resumen = {
            "schema": "abm_resumen_estado_v1",
            "fecha_proceso": now_ts(),
            "hoy": today_local().isoformat(),
            "dias_proximos_vencimientos": dias_prox,
            "totales": {
                "socios_procesados": 0,
                "estado_OK": 0,
                "estado_REVISAR": 0,
                "estado_BLOQUEA": 0,
                "items_faltantes": 0,
                "items_vencidos": 0,
                "items_proximos": 0,
                "items_revisar": 0,
            }
        }

        for f in files:
            socio_uid_safe, out = process_socio_file(Path(f), requisitos, dias_prox)

            # contadores
            resumen["totales"]["socios_procesados"] += 1
            eg = out["estado_global"]
            if eg == "OK":
                resumen["totales"]["estado_OK"] += 1
            elif eg == "REVISAR":
                resumen["totales"]["estado_REVISAR"] += 1
            else:
                resumen["totales"]["estado_BLOQUEA"] += 1

            for it in out["items"]:
                st = it["estado"]
                if st == "FALTANTE":
                    resumen["totales"]["items_faltantes"] += 1
                elif st == "VENCIDO":
                    resumen["totales"]["items_vencidos"] += 1
                elif st == "PROXIMO":
                    resumen["totales"]["items_proximos"] += 1
                elif st == "REVISAR":
                    resumen["totales"]["items_revisar"] += 1

            out_path = OUT_SOCIOS / f"SOCIO_{socio_uid_safe}_ESTADO.json"
            out_path.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")

        OUT_RESUMEN.parent.mkdir(parents=True, exist_ok=True)
        OUT_RESUMEN.write_text(json.dumps(resumen, ensure_ascii=False, indent=2), encoding="utf-8")

        messagebox.showinfo("Listo", f"Procesados: {resumen['totales']['socios_procesados']}\nSalida:\n{OUT_SOCIOS}\nResumen:\n{OUT_RESUMEN}")
        os.startfile(str(OUT_SOCIOS))

    except Exception as e:
        messagebox.showerror("Error", f"{type(e).__name__}: {e}")


# ----------------- UI -----------------
root = tk.Tk()
root.title("ABM – Paso D | Estado + alertas (SOCIO aportes → ESTADO)")
root.geometry("720x320")
root.resizable(False, False)

frame = tk.Frame(root)
frame.pack(pady=16)

tk.Label(frame, text="Ventana de “próximos vencimientos” (días):").grid(row=0, column=0, sticky="w", padx=10, pady=6)
dias_var = tk.StringVar(value="30")
tk.Entry(frame, textvariable=dias_var, width=10).grid(row=0, column=1, sticky="w", padx=10, pady=6)

tk.Button(root, text="Seleccionar SOCIO_*.json (Paso C.1) y generar estado", height=2, command=run_gui).pack(pady=18)

tk.Label(
    root,
    text="Entrada esperada:\n./json_llm/03_aportes/socios/SOCIO_*.json\n\nSalida:\n./json_llm/04_estado/socios/SOCIO_<uid>_ESTADO.json\n./json_llm/04_estado/resumen.json",
    fg="gray"
).pack()

root.mainloop()
